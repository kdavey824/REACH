import time
from adafruit_servokit import ServoKit
skit = ServoKit(channels=16,address=0x41)
num_motor = 5

skit.servo[0].angle = 180

var = 1
while var == 1 :
    skit.servo[0].angle = 75
    time.sleep(3)
    skit.servo[0].angle = 90
    time.sleep(3)
    skit.servo[0].angle = 180
    time.sleep(3)
    skit.servo[0].angle = 60
    time.sleep(3)


    