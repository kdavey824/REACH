import numpy

data = numpy.genfromtxt('vals1.dat', delimiter=',')
print(data)