import pygame
from pygame.locals import *

pygame.init()
w, h = 800, 520
scr = pygame.display.set_mode((w, h))
font = pygame.font.Font(None, 30)
while True:
    
    events = pygame.event.get()
    for ev in events:
        if ev.type == KEYDOWN:
            print(ev.key)