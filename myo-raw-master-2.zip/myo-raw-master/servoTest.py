#!/usr/bin/python
import time
import sys
import numpy as np

try:
    from sklearn import neighbors, svm
    HAVE_SK = True
except ImportError:
    HAVE_SK = False

import struct

import myo

from adafruit_servokit import ServoKit
kit = ServoKit(channels=16,address=0x41)
num_motor = 5

class switch(object):
    def __init__(self, value):
        self.value = value
        self.fall = False

    def __iter__(self):
        """Return the match method once, then stop"""
        yield self.match
        raise StopIteration

    def match(self, *args):
        """Indicate whether or not to enter a case suite"""
        if self.fall or not args:
            return True
        elif self.value in args: # changed for v1.5, see below
            self.fall = True
            return True
        else:
            return False
        
m = myo.Myo(myo.NNClassifier(), sys.argv[1] if len(sys.argv) >= 2 else None)
    
m.add_raw_pose_handler(print)

m.connect()

var = 1 
while var == 1 :
    m.run()
    #pos = input("Desired Position :")
    pos = m.last_pose
    print(m.last_pose)
    continue
    for case in switch(pos):
        print("Case: ", case)
        if case(0):
            pass
            for i in range(num_motor):
                #print("Num_motors: ", num_motor)
                if i == 1 :
                    kit.servo[0].angle = 180
                else :
                    kit.servo[i].angle = 0
                    time.sleep(1)
            break
        if case(1.0):
            for j in range(num_motor):
                #print("Num_motors: ", num_motor)
                print("Current Pose: ", m.last_pose)
                if j == 1:
                    pass
                else:
                    kit.servo[j].angle = 180
                    time.sleep(1)
            break
        if case('3'):
            for k in range(num_motor):
                print("Num_motors: ", num_motor)
                kit.servo[k].angle = 90
                time.sleep(1)
            break
        if case('4'):
            for k in range(num_motor):
                print("Num_motors: ", num_motor)
                kit.servo[k].angle = 35
                time.sleep(1)
            break
